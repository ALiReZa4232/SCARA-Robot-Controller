
#include "I2C_LCD.h"

extern I2C_HandleTypeDef hi2c1;

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
uint8_t DisplayCtrl = 0;
uint8_t BacklightValue = 0;
uint8_t I2C_LCD_Cols = 0;
uint8_t I2C_LCD_Rows = 0;	

/*---------------------[STATIC INTERNAL FUNCTIONS]-----------------------*/
static void I2C_LCD_ExpanderWrite(uint8_t DATA)
{
	uint8_t TxData = (DATA) | BacklightValue;
	HAL_I2C_Master_Transmit(&hi2c1, (I2C_LCD_Address << 1), &TxData, sizeof(TxData), 10);
}

static void I2C_LCD_EnPulse(uint8_t DATA)
{
	I2C_LCD_ExpanderWrite(DATA | EN); // En high
	delay_us(2); // enable pulse must be >450ns

	I2C_LCD_ExpanderWrite(DATA & ~EN); // En low
	delay_us(50); // commands need > 37us to settle
}

static void I2C_LCD_Write4Bits(uint8_t Value)
{
	I2C_LCD_ExpanderWrite(Value);
	I2C_LCD_EnPulse(Value);
}

static void I2C_LCD_Send(uint8_t Value, uint8_t Mode)
{
	uint8_t HighNib = Value & 0xF0;
	uint8_t LowNib = (Value << 4) & 0xF0;
	I2C_LCD_Write4Bits((HighNib) | Mode);
	I2C_LCD_Write4Bits((LowNib) | Mode);
}

static void I2C_LCD_Cmd(uint8_t CMD)
{
	I2C_LCD_Send(CMD, 0);
}

static void I2C_LCD_Data(uint8_t DATA)
{
	I2C_LCD_Send(DATA, 1);
}

/*-----------------------[USER EXTERNAL FUNCTIONS]-----------------------*/
void I2C_LCD_Init(uint8_t cols, uint8_t rows)
{
	// According To Datasheet, We Must Wait At Least 40ms After Power Up Before Interacting With The LCD Module
	HAL_Delay(45);
	I2C_LCD_Cmd(0x30);
	HAL_Delay(5);  // Delay > 4.1ms
	I2C_LCD_Cmd(0x30);
	HAL_Delay(5);  // Delay > 4.1ms
	I2C_LCD_Cmd(0x30);
	HAL_Delay(150);  // Delay > 100μs
	I2C_LCD_Cmd(0x02);

	// Set LCD width and height
	I2C_LCD_Cols = cols;
	I2C_LCD_Rows = rows;

	// Configure the LCD
	I2C_LCD_Cmd(LCD_FUNCTIONSET | LCD_4BITMODE | LCD_2LINE | LCD_5x8DOTS);
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF);
	I2C_LCD_Cmd(LCD_ENTRYMODESET | LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT);
	DisplayCtrl = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;
	BacklightValue = LCD_BACKLIGHT;

	// Clear the LCD
	I2C_LCD_Clear();
}

void I2C_LCD_Clear(void)
{
	I2C_LCD_Cmd(LCD_CLEARDISPLAY);
	HAL_Delay(2);
}

void I2C_LCD_Home(void)
{
	I2C_LCD_Cmd(LCD_RETURNHOME);
	HAL_Delay(2);
}

void I2C_LCD_SetCursor(uint8_t Col, uint8_t Row)
{
	int Row_Offsets[] = {0x00, 0x40, 0x14, 0x54};
	if (Row > I2C_LCD_Rows)
	{
		Row = I2C_LCD_Rows - 1;
	}
	I2C_LCD_Cmd(LCD_SETDDRAMADDR | (Col + Row_Offsets[Row]));
}

void I2C_LCD_WriteChar(uint8_t Col, uint8_t Row, char Ch)
{
  I2C_LCD_SetCursor(Col, Row);
  I2C_LCD_Data(Ch);
}

void I2C_LCD_WriteString(uint8_t Col, uint8_t Row, char *Str)
{	
  I2C_LCD_SetCursor(Col, Row);
  while(*Str) I2C_LCD_Data(*Str++);
}

void I2C_LCD_ShiftLeft(void)
{
  I2C_LCD_Cmd(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}

void I2C_LCD_ShiftRight(void)
{
  I2C_LCD_Cmd(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}

void I2C_LCD_Backlight(void)
{
	BacklightValue = LCD_BACKLIGHT;
  I2C_LCD_ExpanderWrite(0);
}

void I2C_LCD_NoBacklight(void)
{
	BacklightValue = LCD_NOBACKLIGHT;
  I2C_LCD_ExpanderWrite(0);
}

void I2C_LCD_Display(void)
{
	DisplayCtrl |= LCD_DISPLAYON;
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | DisplayCtrl);
}

void I2C_LCD_NoDisplay(void)
{
	DisplayCtrl &= ~LCD_DISPLAYON;
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | DisplayCtrl);
}

void I2C_LCD_Cursor(void)
{
	DisplayCtrl |= LCD_CURSORON;
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | DisplayCtrl);
}

void I2C_LCD_NoCursor(void)
{
	DisplayCtrl &= ~LCD_CURSORON;
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | DisplayCtrl);
}

void I2C_LCD_Blink(void)
{
	DisplayCtrl |= LCD_BLINKON;
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | DisplayCtrl);
}

void I2C_LCD_NoBlink(void)
{
	DisplayCtrl &= ~LCD_BLINKON;
	I2C_LCD_Cmd(LCD_DISPLAYCONTROL | DisplayCtrl);
}

void I2C_LCD_CreateCustomChar(uint8_t CharIndex, const uint8_t* CharMap)
{
	CharIndex &= 0x07;
	I2C_LCD_Cmd(LCD_SETCGRAMADDR | (CharIndex << 3));
	for(uint8_t i = 0; i < 8; i++)
	{
		I2C_LCD_Send(CharMap[i], RS);
	}
}

void I2C_LCD_PrintCustomChar(uint8_t Col, uint8_t Row, uint8_t CharIndex)
{
	I2C_LCD_SetCursor(Col, Row);
	I2C_LCD_Send(CharIndex, RS);
}