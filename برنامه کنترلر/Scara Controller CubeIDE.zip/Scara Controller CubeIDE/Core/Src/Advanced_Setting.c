
#include "Advanced_Setting.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern TIM_HandleTypeDef htim2;

extern uint8_t accessLevel;
extern uint8_t settingIndex;
extern uint8_t currentIndex;

extern uint16_t EncoderCounter;

extern float counter_2;

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char *advancedMenu [5] = {"StepperMotor1" , "StepperMotor2", "StepperMotor3" , "SET jointLength1" , "SET jointLength2"};
char *STPMotorsMenu [2] = {"SET SPEED" , "SET Pulse/rev"};
char *PulseRevMenu [4] = {"800 PPR" , "1600 PPR" , "3200 PPR" , "6400 PPR"};

uint8_t advancedIndex = 0;
uint8_t PulseRevValue = 0;

uint16_t Pulse_rev[3];
uint16_t Pulse_revMenu[4] = {800 , 1600 , 3200 , 6400};

float speedValue[3];
float jointLength_1 = 300.0 , jointLength_2 = 200.0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
void AdvancedSetting(void){
  advancedIndex = EncoderCounter % 5;	

	if(advancedIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = advancedIndex;
	}	
	
	I2C_LCD_WriteString(0 , 0 , advancedMenu[advancedIndex]);
	I2C_LCD_WriteString(0 , 1 , "<Back      Next>");
		
	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		accessLevel = 2 ;
		I2C_LCD_Clear();
		switch(advancedIndex){
			case 0 : while(accessLevel == 2) STPMotors(); break;
			
			case 1 : while(accessLevel == 2) STPMotors(); break; 
			
			case 2 : while(accessLevel == 2) STPMotors(); break; 
			
			case 3 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Length1:");
				I2C_LCD_WriteString(1 , 1 , "000.0 mm");	
				while(accessLevel == 2) jointLength_1 = Calculator_2(1 , 0 , advancedIndex);
				sendSetting(9 , jointLength_1);
			break;
			
			case 4 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Length2:");
				I2C_LCD_WriteString(1 , 1 , "000.0 mm");	
				while(accessLevel == 2) jointLength_2 = Calculator_2(1 , 0 , advancedIndex);
				sendSetting(10 , jointLength_2);
			break;
		}	
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = settingIndex * 2;
		accessLevel = 0;
		I2C_LCD_Clear(); 
	}			
}	

void STPMotors(void){
  uint8_t STPMotorIndex = EncoderCounter % 2;	

	if(STPMotorIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = STPMotorIndex;
	}	
	I2C_LCD_WriteString(1 , 0 , STPMotorsMenu[0]);
	I2C_LCD_WriteString(1 , 1 , STPMotorsMenu[1]);
	I2C_LCD_WriteString(0, STPMotorIndex % 2 , ">");
	
	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		accessLevel = 3;
		I2C_LCD_Clear();		
		switch(STPMotorIndex){
			case 0 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "SPEED:");
				I2C_LCD_WriteString(0 , 1 , "0000 Pulse/s");	
				while(accessLevel == 3) speedValue[advancedIndex] = Calculator_1(2 , 0 , STPMotorIndex);
			
				if(advancedIndex == 0) sendSetting(3 , speedValue[advancedIndex]);
				else if(advancedIndex == 1) sendSetting(5 , speedValue[advancedIndex]);
				else if(advancedIndex == 2) sendSetting(7 , speedValue[advancedIndex]);
			break;

			case 1 : 
				while(accessLevel == 3) PulseRevSelectValue(2 , STPMotorIndex);
				Pulse_rev[advancedIndex] = Pulse_revMenu[PulseRevValue];
			
				if(advancedIndex == 0) sendSetting(4 , PulseRevValue);
				else if(advancedIndex == 1) sendSetting(6 , PulseRevValue);
				else if(advancedIndex == 2) sendSetting(8 , PulseRevValue);	
			break;			
		}
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		
		TIM2->CNT = advancedIndex * 2;
	  accessLevel = 1;
		I2C_LCD_Clear();
	}			
}

void PulseRevSelectValue(uint8_t Level , uint8_t Position){
	uint8_t PulseRevIndex = EncoderCounter % 4;

	if(PulseRevIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = PulseRevIndex;
	}	    
	
	I2C_LCD_WriteString(0 , 0 , ">");
	I2C_LCD_WriteString(1 , 0 , PulseRevMenu[PulseRevIndex]);
	I2C_LCD_WriteString(0 , 1 , PulseRevMenu[(PulseRevIndex + 1) % 4]);

	if(SaveExit_Button == 0){
		HAL_Delay(150);
		PulseRevValue = PulseRevIndex;
		TIM2->CNT = Position * 2;
		accessLevel = Level;
		I2C_LCD_Clear();
	}
}