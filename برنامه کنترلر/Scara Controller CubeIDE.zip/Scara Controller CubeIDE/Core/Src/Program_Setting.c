
#include "Program_Setting.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern TIM_HandleTypeDef htim2;

extern _Bool kinematicType;
extern bool runPosition , runCode , moveMode;

extern uint8_t accessLevel;
extern uint8_t settingIndex;
extern uint8_t currentIndex;

extern uint16_t EncoderCounter;
extern uint16_t indexCode;

extern float counter_2;
extern float Reference[3];
extern float jointLength_1 , jointLength_2;

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char *inverseMenu [4] = {"SET X Axis" , "SET Y Axis" , "SET Z Axis" , "Program Delay"};
char *forwardMenu [3] = {"SET Joint1" , "SET Joint2" , "SET Z Axis"};
char *programMenu [3] = {"Set Position" , "Run Program" , "Clear Program"};

_Bool positionPermit = 0;
bool State = false;

uint8_t programIndex = 0;
uint8_t forwardIndex = 0;
uint8_t inverseIndex = 0;
uint8_t mapNumber = 100;

uint16_t PositionCounter = 0;
uint16_t JointCounter = 0;
uint16_t DelayValue = 100; // in milisecond
uint16_t indexCodeState = 0;

float thetaAngle_1[25] , thetaAngle_2[25] , zAxle[25];
float xPosition[2] , yPosition[2];

float jointAngle_1 = 0.0 , jointAngle_2 = 0.0;
float betaAngle_1 = 0.0 , betaAngle_2 = 0.0;
float xAxis = 0.0 , yAxis = 0.0 , zAxis = 0.0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
float Mapf(float x, float in_min, float in_max, float out_min, float out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void ProgramSetting(void){
  programIndex = EncoderCounter % 3;	

	if(programIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = programIndex;
	}	

	I2C_LCD_WriteString(0 , 0 , ">");
	I2C_LCD_WriteString(1 , 0 , programMenu[programIndex]);
	I2C_LCD_WriteString(0 , 1 , programMenu[(programIndex + 1) % 3]);

	RunMoveFromServer();
	RunCodeFromServer();
	
	if(Enter_Button == 0 && programIndex == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		accessLevel = 2;
		I2C_LCD_Clear();
		while(accessLevel == 2) SetPosition();		
	}

	if(Run_Button == 0 && programIndex == 1){
		HAL_Delay(150);
		RunProgram();
	}
	
	if(Enter_Button == 0 && programIndex == 2){
		I2C_LCD_Clear();
		I2C_LCD_WriteString(2 , 0 , "Clear Done!");
		HAL_Delay(1000);
		I2C_LCD_Clear();
		ClearProgram();
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = settingIndex * 2;
		accessLevel = 0;
		I2C_LCD_Clear(); 
	}			
}

void RunProgram(void){
	if(kinematicType == 1){
		if(JointCounter == 0){
			I2C_LCD_Clear();
			I2C_LCD_WriteString(1 , 0 , "Program Empty!");
			HAL_Delay(1000);
			I2C_LCD_Clear();
		}
		else {
			I2C_LCD_Clear();
			I2C_LCD_WriteString(0 , 0 , "Program Running!");
			
			for(uint16_t i = 0 ; i < JointCounter ; i++){
				if(Stop_Button == 0) break;
				ForwardRunPosition(i);
			}
			I2C_LCD_Clear();
		}
	}
	else {
		if(PositionCounter == 0){
			I2C_LCD_Clear();
			I2C_LCD_WriteString(1 , 0 , "Program Empty!");
			HAL_Delay(1000);
			I2C_LCD_Clear();
		}
		else {
			sendRun();
		}
	}
}

void RunMoveFromServer(void){
	if(moveMode){
		I2C_LCD_Clear();
		I2C_LCD_WriteString(0 , 0 , "Program Running!");
	
		inverseKinematic(xPosition[1] , yPosition[1]);
		
		xPosition[0] = xPosition[1];
		yPosition[0] = yPosition[1];
		
		I2C_LCD_Clear();
	}		
}
	
void RunCodeFromServer(void){
	
	if(runPosition || runCode && indexCode != indexCodeState){
		indexCodeState = indexCode;
		I2C_LCD_Clear();
		I2C_LCD_WriteString(0 , 0 , "Program Running!");
		
		if(fabs(xPosition[1] - xPosition[0]) > 50.0 || fabs(yPosition[1] - yPosition[0]) > 50.0){
			for(uint16_t i = 0; i <= mapNumber; i++){
		
				if(Stop_Button == 0){
					HAL_Delay(150);
					sendPause();
					break;
				}
					
				float xPos = Mapf(i, 0, mapNumber, xPosition[0], xPosition[1]);
				float yPos = Mapf(i, 0, mapNumber, yPosition[0], yPosition[1]);
				inverseKinematic(xPos , yPos);
			}	
			sendOk();
			xPosition[0] = xPosition[1];
			yPosition[0] = yPosition[1];	
		}	
		else {
			inverseKinematic(xPosition[1] , yPosition[1]);
			
			sendOk();
			xPosition[0] = xPosition[1];
			yPosition[0] = yPosition[1];
		}
		I2C_LCD_Clear();
	}
}

void ClearProgram(void){

	for(uint16_t i = 0 ; i < JointCounter ; i++){
		thetaAngle_1[i] = 0.0;
		thetaAngle_2[i] = 0.0;
		zAxle[i] = 0.0;
	}
	sendClear();
}

void SetPosition(void){
	char count[6];

	if(kinematicType == 1){
		if(JointCounter != currentIndex){
			I2C_LCD_WriteString(12 , 0 , "    ");
			currentIndex = JointCounter;
		}	
		
		sprintf(count , "%d" , JointCounter);

		I2C_LCD_WriteString(3 , 0 , "Position ");
		I2C_LCD_WriteString(12 , 0 , count);
		I2C_LCD_WriteString(0 , 1 , "<Back      Next>");		

		if(Enter_Button == 0){
			HAL_Delay(150);
			TIM2->CNT = 0;
			accessLevel = 3;
			jointAngle_1 = 0.0;
			jointAngle_2 = 0.0;
			zAxis = 0.0;
			I2C_LCD_Clear();
			while(accessLevel == 3) Forward();
		}		
	}
	else {
		if(PositionCounter != currentIndex){
			I2C_LCD_WriteString(12 , 0 , "  ");
			currentIndex = PositionCounter;
		}	
		
		sprintf(count , "%d" , PositionCounter + 1);

		I2C_LCD_WriteString(3 , 0 , "Position ");
		I2C_LCD_WriteString(12 , 0 , count);
		I2C_LCD_WriteString(0 , 1 , "<Back      Next>");
		
		if(Enter_Button == 0){
			HAL_Delay(150);
			TIM2->CNT = 0;
			accessLevel = 3;
			xAxis = 0.0;
			yAxis = 0.0;
			zAxis = 0.0;
			I2C_LCD_Clear();
			while(accessLevel == 3) Inverse();
		}				
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = programIndex * 2;
		accessLevel = 1;
		I2C_LCD_Clear();
	}	
}

void inverseKinematic(float x, float y){
	
	float C2 = (pow(x, 2) + pow(y, 2) - pow(jointLength_1, 2) - pow(jointLength_2, 2)) / (2 * jointLength_1 * jointLength_2);
	if (C2 < -1) C2 = -1;
	if (C2 > 1) C2 = 1;
	
	float theta2 = -1 * acos(C2); 
	float theta1 = atan2(y, x) - atan2((jointLength_2 * sin(theta2)), (jointLength_1 + jointLength_2 * cos(theta2)));
	
	betaAngle_1 = theta1 * 180 / 3.14;
	betaAngle_2 = theta2 * 180 / 3.14; // radians to degrees
	
	InverseRunPosition();
}

void Inverse(void){
  inverseIndex = EncoderCounter % 4;	

	if(inverseIndex != currentIndex){
		I2C_LCD_Clear( );
		currentIndex = inverseIndex;
	}	
	
	I2C_LCD_WriteString(0 , 0 , inverseMenu[inverseIndex]);
		
	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		accessLevel = 4;
		I2C_LCD_Clear();		
		switch(inverseIndex){
			case 0 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "X Axis:");
				I2C_LCD_WriteString(1 , 1 , "000.0 mm");	
				while(accessLevel == 4) xAxis = Calculator_2(3 , 1 , inverseIndex);
			break;

			case 1 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Y Axis:");
				I2C_LCD_WriteString(1 , 1 , "000.0 mm");	
				while(accessLevel == 4) yAxis = Calculator_2(3 , 1 , inverseIndex);
			break;
			
			case 2 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Z Axis:");
				I2C_LCD_WriteString(1 , 1 , "000.0 mm");	
				while(accessLevel == 4) zAxis = Calculator_2(3 , 1 , inverseIndex);
			break;
			
			case 3 :
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Delay:");
				I2C_LCD_WriteString(0 , 1 , "0000 ms");	
				while(accessLevel == 4) DelayValue = Calculator_1(3 , 0 , inverseIndex);
			break;				
		}
	}

	if((pow(xAxis, 2) + pow(yAxis, 2)) > pow(165, 2) && (pow(xAxis, 2) + pow(yAxis, 2)) <= pow(500, 2)){
		State = true;
		I2C_LCD_WriteString(1 , 1 , "              ");
	}
	else {
		State = false;
		I2C_LCD_WriteString(1 , 1 , "Invalid Value!");
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		if(State) sendProgram(xAxis , yAxis , zAxis , DelayValue);
		State = false;
		TIM2->CNT = PositionCounter * 2;
		accessLevel = 2;
		positionPermit = 0;
		I2C_LCD_Clear();
	}	
}

void Forward(void){
  forwardIndex = EncoderCounter % 3;	

	if(forwardIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = forwardIndex;
	}	
	
	I2C_LCD_WriteString(0 , 0 , forwardMenu[forwardIndex]);
		
	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		accessLevel = 4;
		I2C_LCD_Clear();		
		switch(forwardIndex){
			case 0 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Joint1:");
				I2C_LCD_WriteString(1 , 1 , "000.0");
				I2C_LCD_PrintCustomChar(6 , 1 , 0);
				while(accessLevel == 4) jointAngle_1 = Calculator_2(3 , 1 , forwardIndex);
			break;

			case 1 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Joint2:");
				I2C_LCD_WriteString(1 , 1 , "000.0");	
				I2C_LCD_PrintCustomChar(6 , 1 , 0);
				while(accessLevel == 4) jointAngle_2 = Calculator_2(3 , 1 , forwardIndex);
			break;
			
			case 2 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "Z Axis:");
				I2C_LCD_WriteString(1 , 1 , "000.0 mm");	
				while(accessLevel == 4) zAxis = Calculator_2(3 , 1 , forwardIndex);
			break;				
		}
	}
	
	if(jointAngle_1 >= -Reference[0] && jointAngle_1 <= Reference[0] && jointAngle_2 >= -Reference[1] && jointAngle_2 <= Reference[1] && zAxis >= -Reference[2] && zAxis <= Reference[2]){
		thetaAngle_1[JointCounter] = jointAngle_1;	
		thetaAngle_2[JointCounter] = jointAngle_2;
		zAxle[JointCounter] = zAxis;
	
		I2C_LCD_WriteString(1 , 1 , "              ");
		positionPermit = 1;
	}
	else {
		I2C_LCD_WriteString(1 , 1 , "Invalid Value!");
		positionPermit = 0;
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = JointCounter * 2;
		accessLevel = 2;
		if(positionPermit == 1) JointCounter++;
		positionPermit = 0;
		I2C_LCD_Clear();
	}		
}
