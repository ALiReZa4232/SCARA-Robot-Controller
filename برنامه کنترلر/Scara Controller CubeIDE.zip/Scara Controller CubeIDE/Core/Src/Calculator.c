
#include "Calculator.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern TIM_HandleTypeDef htim2;

extern uint8_t accessLevel;
extern uint8_t currentIndex;

extern uint16_t EncoderCounter;

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char *multipleMenu_1 [3] = {"x1000" , "x100" , "x10"};
char *multipleMenu_2 [3] = {"x1" , "x0.1" , "x0.01"};
char *multipleMenu_3 [4] = {"x100" , "x10" , "x1" , "x0.1"};

_Bool signType = 0;

uint8_t pointerIndex = 0;
uint8_t numberValue[4];

float counter_2 = 0.0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
float Calculator_1(uint8_t Level , _Bool DecimalPoint , uint8_t Position){
	char count[5];
	uint8_t counter_1 = EncoderCounter % 10; // Max number + 1	

	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		pointerIndex = (pointerIndex + 1) % 3;
	}
	
	if(pointerIndex != currentIndex){
		I2C_LCD_WriteString(11 , 0 , "     ");
		currentIndex = pointerIndex;
	}	
	
	if(DecimalPoint == 1) I2C_LCD_WriteString(11 , 0 , multipleMenu_2[pointerIndex]);
	else I2C_LCD_WriteString(11 , 0 , multipleMenu_1[pointerIndex]);
	
	numberValue[pointerIndex] = counter_1;	
	sprintf(count, "%d", counter_1);
	
	if(DecimalPoint == 1 && pointerIndex > 0) I2C_LCD_WriteString(pointerIndex + 1 , 1 , count); 
	else I2C_LCD_WriteString(pointerIndex , 1 , count);
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		if(DecimalPoint == 1) counter_2 = (numberValue[0] * 1.0) + (numberValue[1] * 0.1) + (numberValue[2] * 0.01);
	  else counter_2 = (numberValue[0] * 1000.0) + (numberValue[1] * 100.0) + (numberValue[2] * 10.0);
		for(uint8_t i = 0 ; i < 4 ; i++) numberValue[i] = 0;
		I2C_LCD_Clear();
		TIM2->CNT = Position * 2;
		pointerIndex = 0;
		accessLevel = Level;
	}
	return counter_2;
}

float Calculator_2(uint8_t Level , _Bool Sign , uint8_t Position){
	char count[5];
	uint8_t counter_1 = EncoderCounter % 10; // Max number + 1	
	
	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		pointerIndex = (pointerIndex + 1) % 4;	
	}
	
	if(pointerIndex != currentIndex){
		I2C_LCD_WriteString(11 , 0 , "    ");
		currentIndex = pointerIndex;
	}	
	
	if(Sign == 1 && Run_Button == 0) {
		HAL_Delay(150);
		signType = (signType + 1) % 2;	
	}
	
	if(Sign == 1 && signType == 1) I2C_LCD_WriteString(0 , 1 , "-");
	else I2C_LCD_WriteString(0 , 1 , "+");			
	
	I2C_LCD_WriteString(11 , 0 , multipleMenu_3[pointerIndex]);			

	numberValue[pointerIndex] = counter_1;	
	sprintf(count, "%d", counter_1);
	
	if(pointerIndex == 3) I2C_LCD_WriteString(pointerIndex + 2, 1 , count); 
	else I2C_LCD_WriteString(pointerIndex + 1 , 1 , count);
		
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		counter_2 = (numberValue[0] * 100.0) + (numberValue[1] * 10.0) + (numberValue[2] * 1.0) + (numberValue[3] * 0.1);
		if(Sign == 1 && signType == 1) counter_2 = -counter_2;
		for(uint8_t i = 0 ; i < 4 ; i++) numberValue[i] = 0;
		I2C_LCD_Clear();
		TIM2->CNT = Position * 2;
		pointerIndex = 0;
		signType = 0;
		accessLevel = Level;
	}
	
	return counter_2;
}