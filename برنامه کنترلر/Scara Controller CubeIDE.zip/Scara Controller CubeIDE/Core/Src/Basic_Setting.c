
#include "Basic_Setting.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern TIM_HandleTypeDef htim2;

extern uint8_t accessLevel;
extern uint8_t settingIndex;
extern uint8_t currentIndex;
extern uint8_t PulseRevValue;

extern uint16_t EncoderCounter;
extern uint16_t Pulse_rev[3] , Pulse_revMenu[4];

extern float counter_2;
extern float speedValue[3];

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char *basicMenu [3] = {"SET SPEED" , "Kinematic Type" , "SET Pulse/rev"};
char *kinematicTypeMenu [2] = {"Inverse" , "Forward"};

_Bool kinematicType = 0;

uint8_t basicIndex = 0;

float Value = 0.0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
void BasicSetting(void){
  basicIndex = EncoderCounter % 3;	

	if(basicIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = basicIndex;
	}	
	
	I2C_LCD_WriteString(0 , 0 , ">");
	I2C_LCD_WriteString(1 , 0 , basicMenu[basicIndex]);
	I2C_LCD_WriteString(0 , 1 , basicMenu[(basicIndex + 1) % 3]);
		
	if(Enter_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = 0;
		accessLevel = 2 ;
		I2C_LCD_Clear();		
		switch(basicIndex){
			case 0 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "SPEED:");
				I2C_LCD_WriteString(0 , 1 , "0000 Pulse/s");	
				while(accessLevel == 2) Value = Calculator_1(1 , 0 , basicIndex);
				for(uint8_t i = 0 ; i < 3 ; i++){
					speedValue[i] = Value; // Set Speed for all StepperMotors			
					sendSetting((i * 2) + 3 , Value); 
					HAL_Delay(50);
				}
				sendSetting(0 , Value);
			break;

			case 1 : while(accessLevel == 2) KinematicSelectType(); break;
			
			case 2 : 
				while(accessLevel == 2) PulseRevSelectValue(1 , basicIndex); 			
				for(uint8_t i = 0 ; i < 3 ; i++){
					Pulse_rev[i] = Pulse_revMenu[PulseRevValue];	
					sendSetting((i * 2) + 4 , PulseRevValue);
					HAL_Delay(50);
				}
				sendSetting(2 , PulseRevValue);
			break;		
		}
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		TIM2->CNT = settingIndex * 2;
		accessLevel = 0;
		I2C_LCD_Clear();
	}		
}
		
void KinematicSelectType(void){
	uint8_t KinematicTypeIndex = EncoderCounter % 2;

	if(KinematicTypeIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = KinematicTypeIndex;
	}	    
	
	I2C_LCD_WriteString(1 , 0 , kinematicTypeMenu[0]);
	I2C_LCD_WriteString(1 , 1 , kinematicTypeMenu[1]);
	I2C_LCD_WriteString(0, KinematicTypeIndex % 2 , ">");

	if(SaveExit_Button == 0){
		HAL_Delay(150);
		if(KinematicTypeIndex == 1) kinematicType = 1;		
		else kinematicType = 0;
		sendSetting(1 , kinematicType);
		TIM2->CNT = basicIndex * 2;
		accessLevel = 1;
		I2C_LCD_Clear();
	}
}