
#include "Server.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern UART_HandleTypeDef huart2;

extern _Bool kinematicType;

extern uint16_t PositionCounter;
extern uint16_t Pulse_rev[3];
extern uint16_t Pulse_revMenu[4];
extern uint16_t indexCodeState;

extern float speedValue[3];
extern float xPosition[2] , yPosition[2];
extern float jointLength_1 , jointLength_2;

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char buffer[50];
char rxBuffer[100];

bool moveMode = false;
bool runPosition = false;
bool runCode = false;
bool homeState[4];

uint8_t rxByte;

uint16_t rxIndex = 0;
uint16_t indexCode = 0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
float extractNumFromCode(char *code, char *character) {
	char *ptr = strstr(code, character);
	
	if(ptr != NULL) {
		ptr += strlen(character);
		return atof(ptr);
	}
	return NAN;
}

/*-----------------------[RECEIVER FUNCTIONS]-----------------------*/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	
	if(huart->Instance == USART2){
		if(rxByte == '\n'){
			rxBuffer[rxIndex] = '\0';
			rxIndex = 0;
						
			if(strstr(rxBuffer, "setting") != NULL) reseiveSetting(rxBuffer);

			else if(strstr(rxBuffer, "Move") != NULL) reseiveMove(rxBuffer);

			else if(strstr(rxBuffer, "End") != NULL){
				runPosition = false;
				runCode = false;
				indexCode = 0;
			}
			else if(strstr(rxBuffer, "Position") != NULL || strstr(rxBuffer, "Code") != NULL){
				reseiveCode(rxBuffer);
			}	
			else if(strstr(rxBuffer, "++") != NULL) PositionCounter++;	
		}
		else {
			if(rxIndex < sizeof(rxBuffer) - 1) rxBuffer[rxIndex++] = rxByte;
		}
		
		HAL_UART_Receive_IT(&huart2, &rxByte, 1);
	}
}

void reseiveSetting(char *code){
	
	if(strstr(rxBuffer, "AutoHoming") != NULL) homeState[0] = true;

	else if(strstr(rxBuffer, "Joint1") != NULL) homeState[1] = true;
	
	else if(strstr(rxBuffer, "Joint2") != NULL) homeState[2] = true;
	
	else if(strstr(rxBuffer, "Joint3") != NULL) homeState[3] = true;
	
	else {
		uint8_t setNum = extractNumFromCode(code, "P");
		uint16_t value = extractNumFromCode(code, "=");
		
		switch(setNum){
			case 0 : for(uint8_t i = 0 ; i < 3 ; i++) speedValue[i] = value; break;	 //Set Speed for all StepperMotors		
			
			case 1 : kinematicType = value; break;	//Set Kinematic Type : Forward or Inverse	
			
			case 2 : for(uint8_t i = 0 ; i < 3 ; i++) Pulse_rev[i] = Pulse_revMenu[value]; break;  //Set Pulse/rev for all StepperMotors
			
			case 3 : speedValue[0] = value; break;  //Set Speed for StepperMotor 1
			
			case 4 : Pulse_rev[0] = Pulse_revMenu[value]; break;  //Set Pulse/rev for StepperMotor 1
			
			case 5 : speedValue[1] = value; break;  //Set Speed for StepperMotor 2
			
			case 6 : Pulse_rev[1] = Pulse_revMenu[value]; break;  //Set Pulse/rev for StepperMotor 2
			
			case 7 : speedValue[2] = value; break;  //Set Speed for StepperMotor 3
			
			case 8 : Pulse_rev[2] = Pulse_revMenu[value]; break;  //Set Pulse/rev for StepperMotor 3
			
			case 9 : jointLength_1 = value; break;  //Set Maximum Length of Joint 1
			
			case 10 : jointLength_2 = value; break;  //Set Maximum Length of Joint 2
		}
	}
}

void reseiveMove(char *code){
	float x , y , z;
	moveMode = true;
	
	x = extractNumFromCode(code, "X");
	y = extractNumFromCode(code, "Y");
	z = extractNumFromCode(code, "Z");	
	
	xPosition[1] = x;
	yPosition[1] = y;
}

void reseiveCode(char *code){
	float x , y , z;
	
	if(strstr(rxBuffer, "Positions Clear") != NULL) PositionCounter = 0;

	else if(strstr(rxBuffer, "Pause") != NULL){
		indexCodeState = 0;
		runPosition = false;
		runCode = false;
	}
	else if(strstr(rxBuffer, "pBack") != NULL){
		indexCodeState = 0;
		runPosition = false;
		runCode = false;
	}
	else{
		if(strstr(rxBuffer, "Position") != NULL){
			if(runPosition == false) runPosition = true;
		}
		else if(strstr(rxBuffer, "Code") != NULL){
			if(runCode == false) runCode = true;
		}
		indexCode = extractNumFromCode(code, "I");
		x = extractNumFromCode(code, "X");
		y = extractNumFromCode(code, "Y");
		z = extractNumFromCode(code, "Z");
		
	  if(!isnan(x)) xPosition[1] = x;
		if(!isnan(y)) yPosition[1] = y;
	}
}

/*-----------------------[SENDER FUNCTIONS]-----------------------*/
void sendProgram(float x , float y , float z , float t){
	memset(buffer, 0, 50);
	sprintf(buffer, "Positions I%d = X%.1f Y%.1f Z%.1f T%.1f\n", PositionCounter + 1, x, y, z, t);
	HAL_UART_Transmit_IT(&huart2, (uint8_t*)buffer, strlen(buffer));
}

void sendRun(void){
	HAL_UART_Transmit_IT(&huart2, (uint8_t*)"Positions Run\n", 14);
}

void sendPause(void){
	if(runPosition){
		HAL_UART_Transmit_IT(&huart2, (uint8_t*)"Positions Pause\n", 16);
		runPosition = false;
		indexCodeState = 0;
	}
	else if(runCode){
		HAL_UART_Transmit_IT(&huart2, (uint8_t*)"Code Pause\n", 11);
		runCode = false;
		indexCodeState = 0;
	}	
}

void sendClear(void){
	HAL_UART_Transmit_IT(&huart2, (uint8_t*)"Positions Clear\n", 16);
	PositionCounter = 0;
}

void sendOk(void){
	HAL_UART_Transmit_IT(&huart2, (uint8_t*)"Ok\n", 3);
}

void sendSetting(int setNum , int value){
	memset(buffer, 0, 50);
	sprintf(buffer, "Setting P%d =%d\n", setNum, value);
	HAL_UART_Transmit_IT(&huart2, (uint8_t*)buffer, strlen(buffer));
}
