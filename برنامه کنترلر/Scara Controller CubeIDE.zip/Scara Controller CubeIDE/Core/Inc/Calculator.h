#ifndef CALCULATOR_H_
#define CALCULATOR_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
float Calculator_1(uint8_t Level , _Bool DecimalPoint , uint8_t Position);
float Calculator_2(uint8_t Level , _Bool Sign , uint8_t Position); 

#endif /* CALCULATOR_H_ */