/*
 * File: I2C_LCD.h
 * Driver Name: [[ I2C_LCD Display ]]
 * SW Layer:   ECUAL
 * Created on: Jan 28, 2024
 * Author:     Khaled Magdy
 * -------------------------------------------
 * For More Information, Tutorials, etc.
 * Visit Website: www.DeepBlueMbedded.com
 *
 */

#ifndef I2C_LCD_H_
#define I2C_LCD_H_

#include "stdint.h"
#include "micros.h"

/*-----------------------[INTERNAL DEFINITIONS]-----------------------*/
// CMD
#define LCD_CLEARDISPLAY        0x01
#define LCD_RETURNHOME          0x02
#define LCD_ENTRYMODESET        0x04
#define LCD_DISPLAYCONTROL      0x08
#define LCD_CURSORSHIFT         0x10
#define LCD_FUNCTIONSET         0x20
#define LCD_SETCGRAMADDR        0x40
#define LCD_SETDDRAMADDR        0x80
// DISPLAY ENTRY
#define LCD_ENTRYRIGHT          0x00
#define LCD_ENTRYLEFT           0x02
#define LCD_ENTRYSHIFTINCREMENT 0x01
#define LCD_ENTRYSHIFTDECREMENT 0x00
// DISPLAY CONTROL
#define LCD_DISPLAYON           0x04
#define LCD_DISPLAYOFF          0x00
#define LCD_CURSORON            0x02
#define LCD_CURSOROFF           0x00
#define LCD_BLINKON             0x01
#define LCD_BLINKOFF            0x00
// CURSOR MOTION
#define LCD_DISPLAYMOVE         0x08
#define LCD_CURSORMOVE          0x00
#define LCD_MOVERIGHT           0x04
#define LCD_MOVELEFT            0x00
// FUNCTION SET
#define LCD_8BITMODE            0x10
#define LCD_4BITMODE            0x00
#define LCD_2LINE               0x08
#define LCD_1LINE               0x00
#define LCD_5x10DOTS            0x04
#define LCD_5x8DOTS             0x00
// BACKLIGHT CONTROL
#define LCD_BACKLIGHT           0x08
#define LCD_NOBACKLIGHT         0x00
#define EN                      0b00000100  // Enable bit
#define RW                      0b00000010  // Read/Write bit
#define RS                      0b00000001  // Register select bit
// I2C Device Address
#define I2C_LCD_Address 0x27    // Make sure the device address is the same

//-----[ Prototypes For User External Functions ]-----
void I2C_LCD_Init(uint8_t cols, uint8_t rows);
void I2C_LCD_Clear(void);
void I2C_LCD_Home(void);
void I2C_LCD_SetCursor(uint8_t Col, uint8_t Row);
void I2C_LCD_WriteChar(uint8_t Col, uint8_t Row, char Ch);
void I2C_LCD_WriteString(uint8_t Col, uint8_t Row, char* Str);

void I2C_LCD_ShiftLeft(void);
void I2C_LCD_ShiftRight(void);

void I2C_LCD_Backlight(void);
void I2C_LCD_NoBacklight(void);
void I2C_LCD_Display(void);
void I2C_LCD_NoDisplay(void);
void I2C_LCD_Cursor(void);
void I2C_LCD_NoCursor(void);
void I2C_LCD_Blink(void);
void I2C_LCD_NoBlink(void);

void I2C_LCD_CreateCustomChar(uint8_t CharIndex, const uint8_t* CharMap);
void I2C_LCD_PrintCustomChar(uint8_t Col, uint8_t Row, uint8_t CharIndex);

#endif /* I2C_LCD_H_ */
