#ifndef BASIC_SETTING_H_
#define BASIC_SETTING_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
void BasicSetting(void);
void KinematicSelectType(void); 
	
#endif /* BASIC_SETTING_H_ */