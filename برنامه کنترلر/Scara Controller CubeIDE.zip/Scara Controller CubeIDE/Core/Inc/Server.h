#ifndef SERVER_H_
#define SERVER_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
float extractNumFromCode(char *code, char *character);

void reseiveSetting(char *code);
void reseiveMove(char *code);
void reseiveCode(char *code);

void sendProgram(float x , float y , float z , float t);
void sendSetting(int setNum , int value);
void sendRun(void);
void sendPause(void);
void sendClear(void);
void sendOk(void);

#endif /* SERVER_H_ */