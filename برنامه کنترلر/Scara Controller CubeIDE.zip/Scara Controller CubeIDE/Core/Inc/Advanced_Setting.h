#ifndef ADVANCED_SETTING_H_
#define ADVANCED_SETTING_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For All User External Functions ]-----
void AdvancedSetting(void);
void STPMotors(void);
void PulseRevSelectValue(uint8_t Level , uint8_t Position);

#endif /* ADVANCED_SETTING_H_ */