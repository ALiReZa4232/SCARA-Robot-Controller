#ifndef PROGRAM_SETTING_H_
#define PROGRAM_SETTING_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
float Mapf(float x, float in_min, float in_max, float out_min, float out_max);

void ProgramSetting(void);
void inverseKinematic(float x, float y);
	
void SetPosition(void);
void RunProgram(void);
void ClearProgram(void);

void Inverse(void);
void Forward(void);

void RunMoveFromServer(void);
void RunCodeFromServer(void);

#endif /* PROGRAM_SETTING_H_ */