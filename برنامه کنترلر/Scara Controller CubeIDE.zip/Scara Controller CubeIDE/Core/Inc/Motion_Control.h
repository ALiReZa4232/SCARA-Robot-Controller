#ifndef MOTION_CONTROL_H_
#define MOTION_CONTROL_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
long Mapi(long x, long in_min, long in_max, long out_min, long out_max);

void LinearMovement_1(uint16_t Speed);
void LinearMovement_2(uint16_t Speed);
	
void TrapezoidalProfile_Motor1(uint16_t Speed , uint16_t Target);
void TrapezoidalProfile_Motor2(uint16_t Speed , uint16_t Target);
	
void SetDirection(void);
void SetSpeed(void);

void ForwardRunPosition(uint16_t positionIndex);
void InverseRunPosition(void);

#endif /* MOTION_CONTROL_H_ */