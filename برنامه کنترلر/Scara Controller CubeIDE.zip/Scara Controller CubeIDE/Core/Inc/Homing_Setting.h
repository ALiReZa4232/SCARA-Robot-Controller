#ifndef HOMING_SETTING_H_
#define HOMING_SETTING_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
void HomingSetting(void);
void AutoHoming(void);
void ManualHoming(void);

void HomingFromServer(void);

void RunHoming_1(uint16_t Speed , _Bool Direction);
void RunHoming_2(uint16_t Speed , _Bool Direction);
//void RunHoming_3(uint16_t Speed , _Bool Direction);

void StepperHoming_1(void);
void StepperHoming_2(void);
//void StepperHoming_3(void);

#endif /* HOMING_SETTING_H_ */