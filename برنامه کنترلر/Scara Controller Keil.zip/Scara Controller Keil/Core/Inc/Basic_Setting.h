#ifndef BASIC_SETTING_H_
#define BASIC_SETTING_H_

#include "SCARA_Configuration.h"

//-----[ Prototypes For User External Functions ]-----
void BasicSetting(void);
void KinematicSelectType(void); 
float Calculator(uint8_t Level , uint8_t Position , _Bool Mode , _Bool Sign); 

#endif /* BASIC_SETTING_H_ */