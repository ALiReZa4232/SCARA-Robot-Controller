/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Encoder_A_Pin GPIO_PIN_0
#define Encoder_A_GPIO_Port GPIOA
#define Encoder_B_Pin GPIO_PIN_1
#define Encoder_B_GPIO_Port GPIOA
#define ESP8266_TX_Pin GPIO_PIN_2
#define ESP8266_TX_GPIO_Port GPIOA
#define ESP8266_RX_Pin GPIO_PIN_3
#define ESP8266_RX_GPIO_Port GPIOA
#define Limit_1_Pin GPIO_PIN_5
#define Limit_1_GPIO_Port GPIOA
#define Limit_2_Pin GPIO_PIN_7
#define Limit_2_GPIO_Port GPIOA
#define Limit_3_Pin GPIO_PIN_0
#define Limit_3_GPIO_Port GPIOB
#define Limit_4_Pin GPIO_PIN_1
#define Limit_4_GPIO_Port GPIOB
#define Limit_5_Pin GPIO_PIN_10
#define Limit_5_GPIO_Port GPIOB
#define Limit_6_Pin GPIO_PIN_11
#define Limit_6_GPIO_Port GPIOB
#define Enter_Pin GPIO_PIN_12
#define Enter_GPIO_Port GPIOB
#define Save_Exit_Pin GPIO_PIN_13
#define Save_Exit_GPIO_Port GPIOB
#define Run_Pin GPIO_PIN_14
#define Run_GPIO_Port GPIOB
#define Stop_Pin GPIO_PIN_15
#define Stop_GPIO_Port GPIOB
#define Pulse_1_Pin GPIO_PIN_8
#define Pulse_1_GPIO_Port GPIOA
#define Direction_1_Pin GPIO_PIN_9
#define Direction_1_GPIO_Port GPIOA
#define Pulse_2_Pin GPIO_PIN_10
#define Pulse_2_GPIO_Port GPIOA
#define Direction_2_Pin GPIO_PIN_11
#define Direction_2_GPIO_Port GPIOA
#define Pulse_3_Pin GPIO_PIN_12
#define Pulse_3_GPIO_Port GPIOA
#define Direction_3_Pin GPIO_PIN_15
#define Direction_3_GPIO_Port GPIOA
#define LCD_SCL_Pin GPIO_PIN_8
#define LCD_SCL_GPIO_Port GPIOB
#define LCD_SDA_Pin GPIO_PIN_9
#define LCD_SDA_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
