
#ifndef SCARA_CONFIGURATION_H_
#define SCARA_CONFIGURATION_H_

/*-----------------------[INTERNAL LIBRARIES]-----------------------*/
#include "stdio.h"
#include "stdbool.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"

/*-----------------------[EXTERNAL LIBRARIES]-----------------------*/
#include "micros.h"
#include "I2C_LCD.h"
#include "Basic_Setting.h"
#include "Advanced_Setting.h"
#include "Program_Setting.h"
#include "Homing_Setting.h"
#include "Motion_Control.h"
#include "Server.h"

/*-----------------------[INTERNAL DEFINITIONS]-----------------------*/
#define Run_Button  HAL_GPIO_ReadPin(GPIOB , Run_Pin) 
#define Stop_Button  HAL_GPIO_ReadPin(GPIOB , Stop_Pin) 
#define Enter_Button  HAL_GPIO_ReadPin(GPIOB , Enter_Pin)
#define SaveExit_Button  HAL_GPIO_ReadPin(GPIOB , Save_Exit_Pin)

#define Encoder_A  HAL_GPIO_ReadPin(GPIOA , Encoder_A_Pin)
#define Encoder_B  HAL_GPIO_ReadPin(GPIOA , Encoder_B_Pin)

#define LimitJoint_1A  HAL_GPIO_ReadPin(GPIOA , Limit_1_Pin)
#define LimitJoint_1B  HAL_GPIO_ReadPin(GPIOA , Limit_2_Pin)
#define LimitJoint_2A  HAL_GPIO_ReadPin(GPIOB , Limit_3_Pin)
#define LimitJoint_2B	 HAL_GPIO_ReadPin(GPIOB , Limit_4_Pin)
#define LimitZAxis_1A	 HAL_GPIO_ReadPin(GPIOB , Limit_5_Pin)
#define LimitZAxis_1B	 HAL_GPIO_ReadPin(GPIOB , Limit_6_Pin)

#define StepperMotor_1_SetPulse  HAL_GPIO_WritePin(GPIOA, Pulse_1_Pin, GPIO_PIN_SET)
#define StepperMotor_1_ResetPulse  HAL_GPIO_WritePin(GPIOA, Pulse_1_Pin, GPIO_PIN_RESET)
#define StepperMotor_1_SetDirection  HAL_GPIO_WritePin(GPIOA, Direction_1_Pin, GPIO_PIN_SET)
#define StepperMotor_1_ResetDirection  HAL_GPIO_WritePin(GPIOA, Direction_1_Pin, GPIO_PIN_RESET)

#define StepperMotor_2_SetPulse  HAL_GPIO_WritePin(GPIOA, Pulse_2_Pin, GPIO_PIN_SET)
#define StepperMotor_2_ResetPulse  HAL_GPIO_WritePin(GPIOA, Pulse_2_Pin, GPIO_PIN_RESET)
#define StepperMotor_2_SetDirection  HAL_GPIO_WritePin(GPIOA, Direction_2_Pin, GPIO_PIN_SET)
#define StepperMotor_2_ResetDirection  HAL_GPIO_WritePin(GPIOA, Direction_2_Pin, GPIO_PIN_RESET)

#define StepperMotor_3_SetPulse  HAL_GPIO_WritePin(GPIOA, Pulse_3_Pin, GPIO_PIN_SET)
#define StepperMotor_3_ResetPulse  HAL_GPIO_WritePin(GPIOA, Pulse_3_Pin, GPIO_PIN_RESET)
#define StepperMotor_3_SetDirection  HAL_GPIO_WritePin(GPIOA, Direction_3_Pin, GPIO_PIN_SET)
#define StepperMotor_3_ResetDirection  HAL_GPIO_WritePin(GPIOA, Direction_3_Pin, GPIO_PIN_RESET)

#define StepperMotor_1_TogglePulse	HAL_GPIO_TogglePin(GPIOA, Pulse_1_Pin)
#define StepperMotor_2_TogglePulse	HAL_GPIO_TogglePin(GPIOA, Pulse_2_Pin)
#define StepperMotor_3_TogglePulse	HAL_GPIO_TogglePin(GPIOA, Pulse_3_Pin)

//-----[ Prototypes For User External Functions ]-----
void ControllerSetup(void);
void ControllerSetting(void);
void ReadEncoder(void);

#endif /* SCARA_CONFIGURATION_H_ */