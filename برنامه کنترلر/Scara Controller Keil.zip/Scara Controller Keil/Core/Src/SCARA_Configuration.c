
#include "SCARA_Configuration.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/

extern UART_HandleTypeDef huart2;
extern uint8_t rxByte;
extern uint16_t Pulse_rev[3];
extern float speedValue[3];
extern float xPosition[2] , yPosition[2];

/*-----------------------[INTERNAL VARIABLES]-----------------------*/

const uint8_t degree[] = {0x07,0x05,0x07,0x00,0x00,0x00,0x00,0x00};
char *settingMenu [4] = {"Basic Setting" , "Advanced Setting" , "Program Setting" , "Homing Setting"};

_Bool A_Now = 0 , A_Before = 0;

uint8_t settingIndex = 0;
uint8_t currentIndex = 0;
uint8_t accessLevel = 0;
uint16_t EncoderCounter = 0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
void ControllerSetup(void){
	HAL_UART_Receive_IT(&huart2, &rxByte, 1);
	
	I2C_LCD_Init(16 , 2);
	I2C_LCD_Backlight();
	I2C_LCD_Display();
	I2C_LCD_CreateCustomChar(0 , degree);
	
    I2C_LCD_WriteString(0 , 0 , "SCARA CONTROLLER");
	I2C_LCD_WriteString(1 , 1 , ">> WELCOME <<");
	
	for(uint8_t i = 0 ; i < 3 ; i++){
		speedValue[i] = 500.0;
		Pulse_rev[i] = 3200;
	}
	xPosition[0] = 500.0;
	yPosition[0] = 0.0;
	
	EncoderCounter = 0;
	
	HAL_Delay(3000);
	I2C_LCD_Clear();	
	
}

void ControllerSetting(void) {
	settingIndex = EncoderCounter % 4;
	
	if(settingIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = settingIndex;
	}	    
	
	I2C_LCD_WriteString(0 , 0 , settingMenu[settingIndex]);
	I2C_LCD_WriteString(0 , 1 , "<Back      Next>");

	HomingFromServer();
	RunMoveFromServer();
	RunCodeFromServer();
	
	if(Enter_Button == 0){
		HAL_Delay(150);
		EncoderCounter = 0;
		accessLevel = 1;
		I2C_LCD_Clear();
		while(accessLevel == 1){
			switch(settingIndex){
				case 0 : BasicSetting(); break;
				
				case 1 : AdvancedSetting(); break;
				
				case 2 : ProgramSetting(); break;
				
				case 3 : HomingSetting(); break;
			}
	  }
  }	
}

void ReadEncoder(void){
	A_Now = Encoder_A;
	
	if(A_Now != A_Before){
		if(Encoder_B != A_Now) EncoderCounter++;
		else EncoderCounter--;
		A_Before = A_Now;
	}
}