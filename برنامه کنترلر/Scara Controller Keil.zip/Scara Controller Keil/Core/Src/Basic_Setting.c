
#include "Basic_Setting.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern uint8_t accessLevel;
extern uint8_t settingIndex;
extern uint8_t currentIndex;
extern uint8_t PulseRevValue;
extern uint16_t EncoderCounter;
extern uint16_t Pulse_rev[3] , Pulse_revMenu[4];
extern float counter_2;
extern float speedValue[3];

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char *basicMenu [3] = {"SET SPEED" , "Kinematic Type" , "SET Pulse/rev"};
char *kinematicTypeMenu [2] = {"Inverse" , "Forward"};
char *multipleMenu_1 [4] = {"x1000" , "x100" , "x10" , "x1"};
char *multipleMenu_2 [4] = {"x100" , "x10" , "x1" , "x0.1"};

_Bool kinematicType = 0;
_Bool signType = 0;

uint8_t basicIndex = 0;
uint8_t pointerIndex = 0;
uint8_t numberValue[4];

float counter_2 = 0.0;
float Value = 0.0;

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
void BasicSetting(void){
  basicIndex = EncoderCounter % 3;	

	if(basicIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = basicIndex;
	}	
	
	I2C_LCD_WriteString(0 , 0 , ">");
	I2C_LCD_WriteString(1 , 0 , basicMenu[basicIndex]);
	I2C_LCD_WriteString(0 , 1 , basicMenu[(basicIndex + 1) % 3]);
		
	if(Enter_Button == 0){
		HAL_Delay(150);
		EncoderCounter = 0;
		accessLevel = 2 ;
		I2C_LCD_Clear();		
		switch(basicIndex){
			case 0 : 
				counter_2 = 0.0;
				I2C_LCD_WriteString(0 , 0 , "SPEED:");
				I2C_LCD_WriteString(1 , 1 , "0000 Pulse/s");	
				while(accessLevel == 2) Value = Calculator(1 , basicIndex , 0 , 0);
				for(uint8_t i = 0 ; i < 3 ; i++){
					speedValue[i] = Value; // Set Speed for all StepperMotors			
					sendSetting((i) + 3 , Value); 
					HAL_Delay(50);
				}
				sendSetting(0 , Value);
			break;

			case 1 : while(accessLevel == 2) KinematicSelectType(); break;
			
			case 2 : 
				while(accessLevel == 2) PulseRevSelectValue(1 , basicIndex); 			
				for(uint8_t i = 0 ; i < 3 ; i++){
					Pulse_rev[i] = Pulse_revMenu[PulseRevValue];	
					sendSetting((i * 2) + 4 , PulseRevValue);
					HAL_Delay(50);
				}
				sendSetting(2 , PulseRevValue);
			break;		
		}
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		EncoderCounter = settingIndex;
		accessLevel = 0;
		I2C_LCD_Clear();
	}		
}
		
void KinematicSelectType(void){
	uint8_t KinematicTypeIndex = EncoderCounter % 2;

	if(KinematicTypeIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = KinematicTypeIndex;
	}	    
	
	I2C_LCD_WriteString(1 , 0 , kinematicTypeMenu[0]);
	I2C_LCD_WriteString(1 , 1 , kinematicTypeMenu[1]);
	I2C_LCD_WriteString(0, KinematicTypeIndex % 2 , ">");

	if(SaveExit_Button == 0){
		HAL_Delay(150);
		if(KinematicTypeIndex == 1) kinematicType = 1;		
		else kinematicType = 0;
		sendSetting(1 , kinematicType);
		EncoderCounter = basicIndex;
		accessLevel = 1;
		I2C_LCD_Clear();
	}
}

float Calculator(uint8_t Level , uint8_t Position , _Bool Mode , _Bool Sign){
	char count[5];
	uint8_t counter_1 = EncoderCounter % 10; // Max number + 1	
	
	if(Enter_Button == 0){
		HAL_Delay(200);
		EncoderCounter = 0;
		pointerIndex = (pointerIndex + 1) % 4;	
	}
	
	if(pointerIndex != currentIndex){
		I2C_LCD_WriteString(11 , 0 , "     ");
		currentIndex = pointerIndex;
	}	
	
	if(Sign == 1 && Run_Button == 0) {
		HAL_Delay(150);
		signType = (signType + 1) % 2;	
	}
	
	if(Sign == 1 && signType == 1) I2C_LCD_WriteString(0 , 1 , "-");
	else I2C_LCD_WriteString(0 , 1 , "+");			
	
	if(Mode == 1) I2C_LCD_WriteString(11 , 0 , multipleMenu_2[pointerIndex]);
	else I2C_LCD_WriteString(11 , 0 , multipleMenu_1[pointerIndex]);

	numberValue[pointerIndex] = counter_1;	
	sprintf(count, "%d", counter_1);
	
	if(Mode == 1 && pointerIndex == 3) I2C_LCD_WriteString(pointerIndex + 2, 1 , count); 
	else I2C_LCD_WriteString(pointerIndex + 1 , 1 , count);
		
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		if(Mode == 1) counter_2 = (numberValue[0] * 100.0) + (numberValue[1] * 10.0) + (numberValue[2] * 1.0) + (numberValue[3] * 0.1);
		else counter_2 = (numberValue[0] * 1000.0) + (numberValue[1] * 100.0) + (numberValue[2] * 10.0) + (numberValue[3] * 1.0); 
			
		if(Sign == 1 && signType == 1) counter_2 = -counter_2;
		for(uint8_t i = 0 ; i < 4 ; i++) numberValue[i] = 0;
		I2C_LCD_Clear();
		EncoderCounter = Position;
		pointerIndex = 0;
		signType = 0;
		accessLevel = Level;
	}
	
	return counter_2;
}