
#include "Homing_Setting.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern bool homeState[4];
extern uint8_t accessLevel;
extern uint8_t settingIndex;
extern uint8_t currentIndex;
extern uint16_t EncoderCounter;
extern uint16_t Pulse_rev[3];

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
char *homingMenu [3] = {"Auto Homing" , "Manual Homing"};
char *manualMenu [3] = {"Home Joint1" , "Home Joint2" , "Home Z"};

uint8_t homingIndex = 0;
uint32_t stepCounter = 0;

float Reference[3];
float currentPosition[3];

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
void RunHoming_1(uint16_t Speed , _Bool Direction){
	
	uint16_t delayTime = round(1000000 / (Speed * 2)); // in micros	
	
	stepCounter++;
	Direction ? StepperMotor_1_SetDirection :	StepperMotor_1_ResetDirection;

	StepperMotor_1_TogglePulse;
	delay_us(delayTime);
}

void RunHoming_2(uint16_t Speed , _Bool Direction){
	
	uint16_t delayTime = round(1000000 / (Speed * 2)); // in micros		
	stepCounter++;
	
	Direction ? StepperMotor_2_SetDirection :	StepperMotor_2_ResetDirection;

	StepperMotor_2_TogglePulse;
	delay_us(delayTime);
}

/*void RunHoming_3(uint16_t Speed , _Bool Direction){
	
	uint32_t delayTime = round(1000000 / (Speed * 2)); // in micros		
	stepCounter++;
	
	Direction ? StepperMotor_3_SetDirection :	StepperMotor_2_ResetDirection;

	StepperMotor_3_TogglePulse;
	delay_us(delayTime);
}*/

void HomingSetting(void){
  homingIndex = EncoderCounter % 2;	

	if(homingIndex != currentIndex){
		I2C_LCD_Clear( );
		currentIndex = homingIndex;
	}	

	I2C_LCD_WriteString(1 , 0 , homingMenu[0]);
	I2C_LCD_WriteString(1 , 1 , homingMenu[1]);
	I2C_LCD_WriteString(0, homingIndex % 2 , ">");
	
	if(homingIndex == 1){
		if(Enter_Button == 0){
			HAL_Delay(150);
			EncoderCounter = 0;
			accessLevel = 2 ;
			I2C_LCD_Clear( );
			while(accessLevel == 2) ManualHoming();	
		}
	}
	
	if(homingIndex == 0){
		if(Run_Button == 0){
			HAL_Delay(150);
			 AutoHoming();
		}
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		EncoderCounter = settingIndex;
		accessLevel = 0;
		I2C_LCD_Clear();
	}		
}

void StepperHoming_1(void){
	stepCounter = 0;
	while(LimitJoint_1A != 0 && Stop_Button != 0) RunHoming_1(500 , 0);
	
	HAL_Delay(100);
	stepCounter = 0;
	while(LimitJoint_1B != 0 && Stop_Button != 0) RunHoming_1(500 , 1); 
	
	
	uint16_t Position = (stepCounter * 0.5) / 2;
	Reference[0] = Position / (Pulse_rev[0]/360.0);
	currentPosition[0] = 0;
	
	HAL_Delay(100);
	stepCounter = 0;
	while(stepCounter != (Position * 2) && Stop_Button != 0) RunHoming_1(500 , 0);
}

void StepperHoming_2(void){
	stepCounter = 0;
	while(LimitJoint_2A != 0 && Stop_Button != 0) RunHoming_2(500 , 1);
	
	HAL_Delay(100);
	stepCounter = 0;
	while(LimitJoint_2B != 0 && Stop_Button != 0) RunHoming_2(500 , 0); 	
	
	uint16_t Position = (stepCounter * 0.5) / 2;
	Reference[1] = Position / (Pulse_rev[1]/360.0);
	currentPosition[1] = 0;
	
	HAL_Delay(100);
	stepCounter = 0;
	while(stepCounter != (Position * 2) && Stop_Button != 0) RunHoming_2(500 , 1);
}

/*void StepperHoming_3(void){
	stepCounter = 0;
	while(LimitZAxis_1A != 0 && Stop_Button != 0) RunHoming_3(500 , 0);
	
	HAL_Delay(100);
	stepCounter = 0;
	while(LimitZAxis_1B != 0 && Stop_Button != 0) RunHoming_3(500 , 1); 	
	
	uint16_t Position = (stepCounter * 0.5) / 2;
	Reference[2] = Position / (Pulse_rev[2] * 2);
	currentPosition[2] = 0;
	
	HAL_Delay(100);
	stepCounter = 0;
	while(stepCounter[0] != Position && Stop_Button != 0) RunHoming_3(500 , 0);
}*/

void AutoHoming(void){  
	StepperHoming_1();
	HAL_Delay(1000);
	StepperHoming_2();
	//HAL_Delay(1000);
	//StepperHoming_3();
}

void ManualHoming(void){
  uint8_t manualIndex = EncoderCounter % 3;	

	if(manualIndex != currentIndex){
		I2C_LCD_Clear();
		currentIndex = manualIndex;
	}	

	I2C_LCD_WriteString(0 , 0 , ">");
	I2C_LCD_WriteString(1 , 0 , manualMenu[manualIndex]);
	I2C_LCD_WriteString(0 , 1 , manualMenu[(manualIndex + 1) % 3]);
		
	if(Run_Button == 0){
		HAL_Delay(150);
		switch(manualIndex){
			case 0 : StepperHoming_1();
			break;
			
			case 1 : StepperHoming_2();
			break;
			
			case 2 : //StepperHoming_3();
			break;
		}		
	}
	
	if(SaveExit_Button == 0){
		HAL_Delay(150);
		EncoderCounter = homingIndex;
		accessLevel = 1;
		I2C_LCD_Clear();
	}		
}

void HomingFromServer(void){
	if(homeState[0]){
		I2C_LCD_Clear();
		I2C_LCD_WriteString(0 , 0 , "Homing Running!");
		AutoHoming();
		I2C_LCD_Clear();
		homeState[0] = false;
	}
	
	if(homeState[1]){
		I2C_LCD_Clear();
		I2C_LCD_WriteString(0 , 0 , "Homing Running!");
		StepperHoming_1();
		I2C_LCD_Clear();
		homeState[1] = false;
	}
	
	if(homeState[2]){
		I2C_LCD_Clear();
		I2C_LCD_WriteString(0 , 0 , "Homing Running!");
		StepperHoming_2();
		I2C_LCD_Clear();
		homeState[2] = false;
	}
	
	/*if(homeState[3]){
		I2C_LCD_Clear();
		I2C_LCD_WriteString(0 , 0 , "Homing Running!");
		StepperHoming_3();
		I2C_LCD_Clear();
		homeState[3] = false;
	}*/
}