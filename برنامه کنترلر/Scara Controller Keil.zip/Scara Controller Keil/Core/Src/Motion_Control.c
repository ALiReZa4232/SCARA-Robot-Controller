
#include "Motion_Control.h"

/*-----------------------[EXTERNAL VARIABLES]-----------------------*/
extern bool runPosition , moveMode;
extern uint16_t Pulse_rev[3];
extern float thetaAngle_1[25] , thetaAngle_2[25] , zAxle[25];
extern float speedValue[3];
extern float currentPosition[3];
extern float betaAngle_1 , betaAngle_2;
extern float xPosition[2] , yPosition[2];

/*-----------------------[INTERNAL VARIABLES]-----------------------*/
uint16_t Speed_1 = 500 , Speed_2 = 500;
uint32_t previousMicros[3];
uint32_t stepCounter_1 = 0;
uint32_t stepCounter_2 = 0;
//uint32_t stepCounter_3 = 0;

float targetPosition[3];

/*-----------------------[EXTERNAL FUNCTIONS]-----------------------*/
long Mapi(long x, long in_min, long in_max, long out_min, long out_max){
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void LinearMovement_1(uint16_t Speed){
	
	uint16_t delayTime = round(1000000 / (Speed * 2)); // in micros	
	
	if(micros() - previousMicros[0] >= delayTime){	  
		StepperMotor_1_TogglePulse;
		previousMicros[0] = micros();
		stepCounter_1++;
	}	
}

void LinearMovement_2(uint16_t Speed){
	
	uint16_t delayTime = round(1000000 / (Speed * 2)); // in micros	
	
	if(micros() - previousMicros[1] >= delayTime){	  
		StepperMotor_2_TogglePulse;
		previousMicros[1] = micros();
		stepCounter_2++;
	}	
}

/*void Trapezoidal_Profile(float maxSpeed , float Acceleration , float Distance){

	// define end point of acceleration and start point of deceleration
	float da = maxSpeed * maxSpeed / (2 * Acceleration);
	float dc = Distance - da;

	if (da > dc) // if we don't even reach full speed
	{
		da = dc = Distance / 2;
		maxSpeed = sqrt(Distance * Acceleration);
	}
	
	float vcurr;
	for (uint32_t incStep = 0; incStep < Distance; incStep++)
	{
		// calculate central position of current step
		float Step = ((float) incStep + 0.5);

		// calculate velocity at current step
		if (Step < da) vcurr = sqrt(2 * Step * Acceleration);
		
		else if (Step < dc) vcurr = maxSpeed;
		
		else vcurr = sqrt(maxSpeed * maxSpeed + 2 * Acceleration * (dc - Step));
		
		// convert velocity to delay
		uint32_t Delay = round(1000000 / vcurr); // in microsecond
		
		StepperMotor_1_SetPulse;
		delay_us(3); 
		StepperMotor_1_ResetPulse;
		delay_us(Delay);
	}
}*/

void TrapezoidalProfile_Motor1(uint16_t Speed , uint16_t Target){

  uint16_t rampStep = Target / 3;
  uint16_t minDelay = round(1000000 / (Speed * 2));
  uint16_t maxDelay = minDelay * sqrt(3);
  uint16_t deltaStep = Target - rampStep;
  uint16_t delayTime = 0;

	if (stepCounter_1 < rampStep) delayTime = Mapi(stepCounter_1, 0, rampStep, maxDelay, minDelay); // Acceleration           

	else if (stepCounter_1 < deltaStep) delayTime = minDelay; //Constant Speed                        

	else delayTime = Mapi(stepCounter_1 - deltaStep, 0, rampStep, minDelay, maxDelay); //Deceleartion

	if(micros() - previousMicros[0] >= delayTime){	  
		StepperMotor_1_TogglePulse;
		previousMicros[0] = micros();
		stepCounter_1++;
	}		
}

void TrapezoidalProfile_Motor2(uint16_t Speed , uint16_t Target){

  uint16_t rampStep = Target / 3;
  uint16_t minDelay = round(1000000 / (Speed * 2));
  uint16_t maxDelay = minDelay * sqrt(3);
  uint16_t deltaStep = Target - rampStep;
  uint16_t delayTime = 0;

	if (stepCounter_2 < rampStep) delayTime = Mapi(stepCounter_2, 0, rampStep, maxDelay, minDelay); // Acceleration           

	else if (stepCounter_2 < deltaStep) delayTime = minDelay; //Constant Speed                         

	else delayTime = Mapi(stepCounter_2 - deltaStep, 0, rampStep, minDelay, maxDelay); //Deceleartion

	if(micros() - previousMicros[1] >= delayTime){	  
		StepperMotor_2_TogglePulse;
		previousMicros[1] = micros();
		stepCounter_2++;
	}		
}

void SetDirection(void){
	
	if(targetPosition[0] < 0){
		StepperMotor_1_ResetDirection;
		targetPosition[0] = fabs(targetPosition[0]);
	}
	else StepperMotor_1_SetDirection;

	if(targetPosition[1] < 0){
		StepperMotor_2_SetDirection;
		targetPosition[1] = fabs(targetPosition[1]);
	}
	else StepperMotor_2_ResetDirection;	
	
	/*if(targetPosition[2] < 0){
		StepperMotor_3_ResetDirection;
		targetPosition[2] = fabs(targetPosition[2]);
	}
	else StepperMotor_3_SetDirection;*/	
}

void SetSpeed(void){
	
	if(targetPosition[0] != targetPosition[1]){
		if(targetPosition[0] > targetPosition[1]){
			Speed_1 = speedValue[0];
			Speed_2 = fabs((targetPosition[1] / targetPosition[0])) * speedValue[0];					
		}				
		else {
			Speed_1 = fabs((targetPosition[0] / targetPosition[1])) * speedValue[1];
			Speed_2 = speedValue[1];					
		}					
	}
	else {
		Speed_1 = speedValue[0];
		Speed_2 = speedValue[1];
	}
}

void ForwardRunPosition(uint16_t positionIndex){
	
	targetPosition[0] =  round((thetaAngle_1[positionIndex] - currentPosition[0]) * (Pulse_rev[0] / 360.0));
	currentPosition[0] = thetaAngle_1[positionIndex]; 		

	targetPosition[1] =  round((thetaAngle_2[positionIndex] - currentPosition[1]) * (Pulse_rev[1] / 360.0));
	currentPosition[1] = thetaAngle_2[positionIndex];			

	/*targetPosition[2] =  round((zAxle[positionIndex] - currentPosition[2]) * (Pulse_rev[2]/stpSizeArray[2]));
	currentPosition[2] = zAxle[positionIndex];*/	
	
	SetDirection();
	SetSpeed();
	
	stepCounter_1 = 0;
	stepCounter_2 = 0;
	//stepCounter_3 = 0;
	
	while(stepCounter_1 != (targetPosition[0] * 2) || stepCounter_2 != (targetPosition[1] * 2)){
		if(Stop_Button == 0) break;
		
		if(LimitJoint_1A == 0 || LimitJoint_1B == 0) break;
		if(LimitJoint_2A == 0 || LimitJoint_2B == 0) break;
		
		if(stepCounter_1 < (targetPosition[0] * 2)) TrapezoidalProfile_Motor1(Speed_1 , (targetPosition[0] * 2)); 
		if(stepCounter_2 < (targetPosition[1] * 2)) TrapezoidalProfile_Motor2(Speed_2 , (targetPosition[1] * 2));  
	}
	
	/*while(stepCounter_3 != targetPosition[2]){
		if(Stop_Button == 0) break;
		if(LimitZAxis_1A == 0 || LimitZAxis_1B == 0) break;
		TriangleProfile_Motor3(speedArray[2] , accelArray[2] , targetPosition[2] , stpSizeArray[2] , triangleMode); // zAxis
	}*/
	
	if(LimitJoint_1A == 0 || LimitJoint_1B == 0){
		StepperHoming_1();
	}
	if(LimitJoint_2A == 0 || LimitJoint_2B == 0){
		StepperHoming_2();
	}
	/*if(LimitZAxis_1A == 0 || LimitZAxis_1B == 0){
		StepperHoming_3();
	}*/
}

void InverseRunPosition(void){
	
	targetPosition[0] =  round((betaAngle_1 - currentPosition[0]) * (Pulse_rev[0] / 360.0));
	currentPosition[0] = betaAngle_1; 		

	targetPosition[1] =  round((betaAngle_2 - currentPosition[1]) * (Pulse_rev[1] / 360.0));
	currentPosition[1] = betaAngle_2;			

	/*targetPosition[2] =  round((zAxle[positionIndex] - currentPosition[2]) * (Pulse_rev[2]/stpSizeArray[2]));
	currentPosition[2] = zAxle[positionIndex];*/	
	
	SetDirection();
	SetSpeed();
	
	stepCounter_1 = 0;
	stepCounter_2 = 0;
	//stepCounter_3 = 0;

	while(stepCounter_1 != (targetPosition[0] * 2) || stepCounter_2 != (targetPosition[1] * 2)){
		
		if(Stop_Button == 0) break;
		
		if(LimitJoint_1A == 0 || LimitJoint_1B == 0) break;
		if(LimitJoint_2A == 0 || LimitJoint_2B == 0) break;

		if(stepCounter_1 < (targetPosition[0] * 2)){
			if(moveMode == true) TrapezoidalProfile_Motor1(Speed_1 , (targetPosition[0] * 2)); 
			else LinearMovement_1(Speed_1); 
		}
		if(stepCounter_2 < (targetPosition[1] * 2)){
			if(moveMode == true) TrapezoidalProfile_Motor2(Speed_2 , (targetPosition[1] * 2));
			else LinearMovement_2(Speed_2);
		}
	}
	
	/*while(stepCounter_3 != targetPosition[2]){
		if(Stop_Button == 0) break;
		if(LimitZAxis_1A == 0 || LimitZAxis_1B == 0) break;
		TriangleProfile_Motor3(speedArray[2] , accelArray[2] , targetPosition[2] , stpSizeArray[2] , triangleMode); // zAxis
	}*/
	
	if(stepCounter_1 == (targetPosition[0] * 2) && stepCounter_2 == (targetPosition[1] * 2)) moveMode = false;
	
	if(LimitJoint_1A == 0 || LimitJoint_1B == 0){
		sendPause();
		StepperHoming_1();
	}
	if(LimitJoint_2A == 0 || LimitJoint_2B == 0){
		sendPause();
		StepperHoming_2();
	}
	/*if(LimitZAxis_1A == 0 || LimitZAxis_1B == 0){
		runPosition = false;
		sendPause();
		StepperHoming_3();
	}*/
}